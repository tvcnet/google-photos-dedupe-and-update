var e,t;"function"==typeof(e=globalThis.define)&&(t=e,e=null),function(t,o,a,n,r){var s="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:"undefined"!=typeof window?window:"undefined"!=typeof global?global:{},c="function"==typeof s[n]&&s[n],i=c.cache||{},l="undefined"!=typeof module&&"function"==typeof module.require&&module.require.bind(module);function u(e,o){if(!i[e]){if(!t[e]){var a="function"==typeof s[n]&&s[n];if(!o&&a)return a(e,!0);if(c)return c(e,!0);if(l&&"string"==typeof e)return l(e);var r=Error("Cannot find module '"+e+"'");throw r.code="MODULE_NOT_FOUND",r}p.resolve=function(o){var a=t[e][1][o];return null!=a?a:o},p.cache={};var d=i[e]=new u.Module(e);t[e][0].call(d.exports,p,d,d.exports,this)}return i[e].exports;function p(e){var t=p.resolve(e);return!1===t?{}:u(t)}}u.isParcelRequire=!0,u.Module=function(e){this.id=e,this.bundle=u,this.exports={}},u.modules=t,u.cache=i,u.parent=c,u.register=function(e,o){t[e]=[function(e,t){t.exports=o},{}]},Object.defineProperty(u,"root",{get:function(){return s[n]}}),s[n]=u;for(var d=0;d<o.length;d++)u(o[d]);if(a){var p=u(a);"object"==typeof exports&&"undefined"!=typeof module?module.exports=p:"function"==typeof e&&e.amd?e(function(){return p}):r&&(this[r]=p)}}({kgW6q:[function(e,t,o){e("../../../background/index")},{"../../../background/index":"lSzt3"}],lSzt3:[function(e,t,o){var a=e("../lib/types");let n={},r={};async function s(){let e=await chrome.tabs.query({url:"https://photos.google.com/*"});return e.length>0?e[0]:null}async function c(e){if(e.tab?.id)return e.tab.id;if(e.url){let t=await chrome.tabs.query({url:e.url});if(t.length>0&&t[0].id)return t[0].id}return null}async function i(e,t,o){let n=`${Date.now()}-${Math.random().toString(36).slice(2,8)}`,s={app:a.APP_ID,action:"gptkCommand",command:t,requestId:n,args:o};return new Promise((t,o)=>{r[n]={resolve:t,reject:o,appTabId:0},chrome.tabs.sendMessage(e,s).catch(()=>{delete r[n],o("Unable to connect to Google Photos tab. Please reload the tab and try again.")})})}async function l(e){let t=await chrome.tabs.create({url:chrome.runtime.getURL("tabs/app.html")});e.tab?.id&&t.id&&(n[e.tab.id]=t.id,n[t.id]=e.tab.id)}async function u(e){let t=await c(e),o=await s();if(!o?.id){t&&chrome.tabs.sendMessage(t,{app:a.APP_ID,action:"healthCheck.result",success:!1,hasGptk:!1});return}t&&o.id&&(n[t]=o.id,n[o.id]=t);try{let e=await i(o.id,"healthCheck");t&&chrome.tabs.sendMessage(t,{app:a.APP_ID,action:"healthCheck.result",success:!0,hasGptk:e.hasGptk,accountEmail:e.accountEmail})}catch{t&&chrome.tabs.sendMessage(t,{app:a.APP_ID,action:"healthCheck.result",success:!1,hasGptk:!1})}}async function d(e,t){let o=await c(t);if(!o)return;let i=n[o];if(!i){let t=await s();if(!t?.id){chrome.tabs.sendMessage(o,{app:a.APP_ID,action:"gptkResult",command:e.command,requestId:e.requestId,success:!1,error:"Google Photos tab not found. Please open photos.google.com."});return}i=t.id,n[o]=i,n[i]=o}r[e.requestId]={resolve:()=>{},reject:()=>{},appTabId:o},chrome.tabs.sendMessage(i,e).catch(()=>{chrome.tabs.sendMessage(o,{app:a.APP_ID,action:"gptkResult",command:e.command,requestId:e.requestId,success:!1,error:"Unable to connect to Google Photos tab. Please reload the tab and try again."}),delete r[e.requestId]})}chrome.runtime.onMessage.addListener((e,t)=>{if(e?.app===a.APP_ID)switch(e.action){case"launchApp":l(t);break;case"healthCheck":u(t);break;case"gptkCommand":d(e,t);break;case"gptkResult":(function(e,t){let o=r[e.requestId];o&&(o.appTabId&&chrome.tabs.sendMessage(o.appTabId,e),e.success?o.resolve(e.data):o.reject(e.error||"Unknown error"),delete r[e.requestId])})(e,0);break;case"gptkProgress":(function(e,t){let o=r[e.requestId];o?.appTabId&&chrome.tabs.sendMessage(o.appTabId,e)})(e,0)}}),chrome.tabs.onRemoved.addListener(e=>{let t=n[e];for(let[o,s]of(t&&(delete n[t],chrome.tabs.sendMessage(t,{app:a.APP_ID,action:"gptkLog",level:"error",message:"Google Photos tab was closed."}).catch(()=>{})),delete n[e],Object.entries(r)))s.appTabId===e&&delete r[o]}),chrome.action.onClicked.addListener(()=>{chrome.tabs.create({url:chrome.runtime.getURL("tabs/app.html")})}),

// Image fetch handler — service worker has no CORS restrictions so it can
// fetch Google Photos thumbnail URLs that are blocked in the page context.
chrome.runtime.onMessage.addListener((msg, sender) => {
    if (msg?.app !== 'GPD' || msg.action !== 'gptkFetchImage') return;
    const { requestId, url } = msg;
    const tabId = sender?.tab?.id;
    if (!tabId) return;
    (async () => {
        try {
            const response = await fetch(url);
            if (!response.ok) {
                chrome.tabs.sendMessage(tabId, { app: 'GPD', action: 'gptkFetchImageResult', requestId, error: `Failed to fetch image: ${response.status}` });
                return;
            }
            const arrayBuffer = await response.arrayBuffer();
            const mimeType = response.headers.get('content-type') || 'image/jpeg';
            // Chunked base64 conversion — avoids call stack overflow for large images.
            const uint8 = new Uint8Array(arrayBuffer);
            let binary = '';
            const chunkSize = 8192;
            for (let i = 0; i < uint8.length; i += chunkSize) {
                binary += String.fromCharCode(...uint8.subarray(i, i + chunkSize));
            }
            const base64 = btoa(binary);
            chrome.tabs.sendMessage(tabId, { app: 'GPD', action: 'gptkFetchImageResult', requestId, base64, mimeType });
        } catch (err) {
            chrome.tabs.sendMessage(tabId, { app: 'GPD', action: 'gptkFetchImageResult', requestId, error: String(err) });
        }
    })();
}),

console.log("GPD: Service worker loaded")},{"../lib/types":"lq6Pm"}],lq6Pm:[function(e,t,o){var a=e("@parcel/transformer-js/src/esmodule-helpers.js");a.defineInteropFlag(o),a.export(o,"APP_ID",()=>n),a.export(o,"DEFAULT_SETTINGS",()=>r);let n="GPD",r={similarityThreshold:.99,scanMode:"smart"}},{"@parcel/transformer-js/src/esmodule-helpers.js":"f6DG4"}],f6DG4:[function(e,t,o){o.interopDefault=function(e){return e&&e.__esModule?e:{default:e}},o.defineInteropFlag=function(e){Object.defineProperty(e,"__esModule",{value:!0})},o.exportAll=function(e,t){return Object.keys(e).forEach(function(o){"default"===o||"__esModule"===o||t.hasOwnProperty(o)||Object.defineProperty(t,o,{enumerable:!0,get:function(){return e[o]}})}),t},o.export=function(e,t,o){Object.defineProperty(e,t,{enumerable:!0,get:o})}},{}]},["kgW6q"],"kgW6q","parcelRequire1ba5"),globalThis.define=t;